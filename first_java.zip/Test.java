public class Test {
  public static void main(String[] args){
    System.out.println("My name is Flynn");
    System.out.println("I am 23 years old");
    System.out.println("My hometown is North Augusta, SC");
  }
}

//'javac' is not recognized as an internal or external command, operable program or batch file.
// also jdk 8 doesn't configure to vscode I need version 11 and I downloaded that but vscode doesn't recognize that either. 
//What terminal was the lady using in the lesson video?